// Define our game id, secret, and capabilities.
const ng_master = {
	appid:"59036:mMCiZWym",
	secret:"PE7YbuYV2aTN77GfWrXr1A==",
    version:"1.0.0",
    hostmatters:false,
    logview:true,
    medals:true,
    scoreboards:true,
    saveslots:false
};

const _ng_options = {
	version:"1.0.0",
    checkHostLicense:false,
    autoLogNewView:true,
    preloadMedals:true,
    preloadScoreBoards:true,
    preloadSaveSlots:false,
	debugMode:false
};

const ng_scoreboards = {
	'highscore_gauntlet_flags_ranked':14173
};

const ng_badges = {
	// NEWGROUNDS COLLECTION
	'got25_aa_newgrounds':78924,
};
